@fruits = ("apple", "banana", "pineapple", "kiwi");
  

print "@fruits\n";
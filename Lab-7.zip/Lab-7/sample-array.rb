exm = [4, 4.0, "Jose", ]   
puts exm   